# infection_scanner

A quick and dirty little Perl script to grep for certain strings that have been found in
various website files.  

This was designed as part of a walkthrough on how to create a cPanel Plugin.  It will likely
not be maintained and is very basic.  


